<?php 

 //select du lieu

include 'ketnoi.php';
// setcookie("sl", "3", time() + (86400 * 1), "/");
// echo $_COOKIE["sl"];
// $sql="select * from th";
// $thucthi=$conn->query($sql);
// //var_dump($thucthi);
// while ($row=mysqli_fetch_array($thucthi)) {
// 	echo $row[0];
// }

$sql="INSERT INTO `th`(`id`, `ten`) VALUES ('','Nguyễn văn A')";
$thucthi=$conn->query($sql);
if($thucthi){
	echo "Thêm thành công";
}
else{
	echo "Thêm không thành công";
}

// $sql="UPDATE `th` SET `ten`='Tên nhân viên' WHERE id='1'";
// $thucthi=$conn->query($sql);
// if($thucthi){
// 	echo "Cập nhật thành công";
// }
// else{
// 	echo "Cập nhật không thành công";
// }
?>