<?php
define('URL_API','https://www.nganluong.vn/checkout.api.nganluong.post.php'); // Đường dẫn gọi api
define('RECEIVER','xxxxx'); // Email tài khoản ngân lượng
define('MERCHANT_ID', 'xxxxx'); // Mã merchant kết nối
define('MERCHANT_PASS', 'xxxxx'); // Mật khẩu kết nôi
?>
