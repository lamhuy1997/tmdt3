<!DOCTYPE html>
<html>
<head>
    <title>Sử dụng Ajax</title>
    <script src="bootstrap_v4/js/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $("#btn_them").click(function(){
                $("#thongbao").text("đang xữ lý...");
                $("#thongbao_img").show();
                $.post(
                    'them.php', // gọi file them.php 
                    {
                        ten:$("#ten").val() // gưi tham số ten đến them.php 
                    },
                function(data){
                    if(data){
                        
                        $("#thongbao").text(data);
                        $("#thongbao_img").hide()
                    }
                }

                )
            })
        })
    </script>
</head>
<body>
  <div style="width:300px;margin:auto;">
      <div>
          <input type="text" name="ten" id="ten">
          <br>
          <button style="width:120px;background-color: blue; color: white;" id="btn_them">Thêm</button>
      </div>
      <div>
          <span id="thongbao" style="color: red;"></span>
      </div>
      <div>
        <img src="tel.png" id="thongbao_img" style="display: none;">
      </div>
  </div>
  
</body>
</html>