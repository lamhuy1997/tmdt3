<?php 
    if(isset($_POST['ten'])){
        $ten=$_POST['ten'];
        include 'ketnoi.php';
        $sql="insert into th(`id`,`ten`) values('','$ten')";
        $thucthi=$conn->query($sql);
        if($thucthi){
            echo "Thêm thành công";
        }
        else{
            echo "thêm không thành công";
        }
    }
  ?>