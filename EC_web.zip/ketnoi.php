<?php 

$conn=mysqli_connect("localhost","root","","ec") or die("kết nối không thành công");
mysqli_set_charset($conn,'UTF8');
?>