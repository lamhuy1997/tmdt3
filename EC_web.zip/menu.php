<!DOCTYPE html>
<html>
<head>
	<title>Menu</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap_v4/css/bootstrap.min.css">
  <script src="bootstrap_v4/js/jquery.min.js"></script>
  <script src="bootstrap_v4/js/popper.min.js"></script>
  <script src="bootstrap_v4/js/bootstrap.min.js"></script>
  <script type="text/javascript">
  	$(document).ready(function(){
  		alert(document.cookie);
  	})
  </script>
</head>
<body>
<div class="container-fluid">
	<div class="container">
		<!-- Thanh menu-->
		<nav class="navbar navbar-expand-sm bg-light navbar-dark"  >
		  <ul class="navbar-nav">
		    <li class="nav-item">
		      <a class="nav-link" href="#" style="color: black;">Trang chủ</a>
		    </li>
		    <li class="nav-item">
		      <a class="nav-link" href="#" style="color: black;">Sản phẩm</a>
		    </li>
		  </ul>
		</nav>

		<div class="container">
			<!--Khung tìm kiếm-->
			<div class="row">
				<div class="col-2">
					hinh anh
				</div>
				<div class="col-6">
					nội dung
				</div>
				<div class="col-4">
					<form class="form-inline" action="/action_page.php">
					    <input class="form-control mr-sm-2" type="text" placeholder="Search">
					    <button class="btn btn-success" type="submit">Search</button>
					 </form>
				</div>
			</div>
			<!--slide/ banner-->
			<div class="row">
				<div class="col-8" style="background-color: red;">
					<center><span>Slide bên phai</span></center>
				</div>
				<div class="col-4" style="background-color: black;">
					<div class="row">
						<div class="col-12">
							<span>Bên trai trên</span>
						</div>
						<div class="col-12">
							<span>Bên trái dưới</span>
						</div>
					</div>
				</div>
			</div>
			<!--Khung sản phẩm-->
			<div >
				<label>Tiêu đề sản phẩm</label>
			</div>
			<div class="row">
				<!--Thông tin sản phẩm 4 cột col-12 col-sm-6 col-lg-2 col-md-3-->
				<?php 
					include "ketnoi.php";
					$sql="select * from th";
					$thucthi=$conn->query($sql);
					if($thucthi){
						while ($row =mysqli_fetch_array($thucthi)) {
									
				?>
				 <div class="col-3" style="border-style:solid; padding: 10px;">
					<span style="position: absolute;right:10px; width: 50px; background-color: green; margin-top: 5px; ">Giảm giá</span>
					<span style="position: absolute;left:10px; width: 50px; background-color:red; margin-top: 5px; ">New</span>
					<div>
						<img src="tel.png" style="width:80%; height: 200px;">
					</div>
					<div> 
						<?php echo $row[1]; ?>
					</div>
					<div>
						<span>Giảm giá</span> <strike> 3000</strike>
						<span>Giá </span>
					</div>
				</div>
				<?php 
						}
					}
				?>
			</div>
			
		</div>
	</div>
</div> 
<!-- Table trong bootstrap -->
<div class="container">
	<table class="table table-hover">
		<thead>
			<tr>
				<td>
					STT
				</td>
				<td>
					Hoteb
				</td>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>
					1 
				</td>
				<td>
					Nguyễn văn a
				</td>
			</tr>
		</tbody>
	</table>
</div>
</body>
</html>